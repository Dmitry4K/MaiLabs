#pragma once
#include"pentagon.h"
#include"rhombus.h"
#include"trapeze.h"
#include"line.h"
#include"curve_line.h"